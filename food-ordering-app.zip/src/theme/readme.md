## Useful link to read API
- https://material-ui.com/styles/api/#themeprovider