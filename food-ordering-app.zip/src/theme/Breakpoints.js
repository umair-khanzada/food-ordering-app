/* eslint-disable no-unused-vars */

// If you need your custom break points used the object below to set it up

const breakpoints = {};
