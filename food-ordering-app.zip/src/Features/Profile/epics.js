// implement redux-observable logic here!!

export const profileEpic = {
  epics: '',
};
