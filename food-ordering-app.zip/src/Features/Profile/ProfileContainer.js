import React from 'react';

function ProfileContainer() {
  return <h1>Profile</h1>;
}

export default ProfileContainer;
