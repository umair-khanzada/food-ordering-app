import React from 'react';

import SignUpForm from './index';

function SignUpContainer() {
  return <SignUpForm />;
}

export default SignUpContainer;
