import React from 'react';

import LoginForm from './index';

function LoginContainer() {
  return <LoginForm />;
}

export default LoginContainer;
