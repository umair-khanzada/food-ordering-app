import styled from 'styled-components';

export const Div = styled.div`
  padding-right: '30px';
`;
