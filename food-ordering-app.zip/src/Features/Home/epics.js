// implement redux-observable logic here!!

export const homeEpic = {
  epics: '',
};
