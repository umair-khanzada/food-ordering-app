import React from 'react';

function HomeContainer() {
  return <h1>Home</h1>;
}

export default HomeContainer;
