import React from 'react';

import MainContainer from './routes/Layout/MainContainer';
const App = () => {
  return <MainContainer />;
};
export default App;
