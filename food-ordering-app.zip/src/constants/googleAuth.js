export const clientId = '763535704430-bc4v8c53e22bf512il3ka4no7cm94bm8.apps.googleusercontent.com';
