const Roles = {
  officeBoy: 'Office_Boy',
  orderPlacer: 'Order_Placer',
};

export default Roles;
