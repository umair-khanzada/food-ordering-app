## Layout Directory to layout the APP
- Use this directory for every layout component